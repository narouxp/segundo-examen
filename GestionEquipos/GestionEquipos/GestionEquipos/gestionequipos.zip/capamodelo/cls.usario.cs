﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GestionEquipos.capamodelo
{
	public class clsusuario
	{
		public string name { get; set; }
		public string apellido { get; set; }
		public int gmail { get; set; }
	}
}